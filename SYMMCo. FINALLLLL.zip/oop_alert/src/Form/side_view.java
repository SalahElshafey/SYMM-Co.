package Form;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.IOException;

public class side_view {
    private Stage signUpStage; // Declare a Stage variable outside the method

    @FXML
    private void handleButtonClick(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("CreditCard.fxml"));
        signUpStage = new Stage();
        signUpStage.setScene(new Scene(root));
        signUpStage.setOnCloseRequest(e -> signUpStage = null); // Set the signUpStage variable to null when closed
        signUpStage.show();
    }
    @FXML
    private void startShake_button(MouseEvent mouseEvent) {
        Button button = (Button) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(button.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(button.translateXProperty(), 0))
        );
        timeline.play();
    }
    private Stage loginStage; // Declare a Stage variable outside the method

    public void switchToScene3(ActionEvent event) throws IOException {
        if (loginStage == null) {
            Parent root = FXMLLoader.load(getClass().getResource("profile.fxml"));
            loginStage = new Stage();
            loginStage.setTitle("Log in");
            loginStage.setScene(new Scene(root));
            loginStage.setOnCloseRequest(e -> loginStage = null); // Set the loginStage variable to null when closed
            loginStage.show();
        }
    }
}
