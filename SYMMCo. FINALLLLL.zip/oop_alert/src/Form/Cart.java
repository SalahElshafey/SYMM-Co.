package Form;

import Classes.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Cart {

    @FXML
    Label nameLabel1;
    @FXML
    Label nameLabel2;
    @FXML
    Label nameLabel3;
    @FXML
    Label nameLabel4;
    String text1;
    String text2;
    String text3;
    String text4;
    private Product product = new Product();
    public void displayName(String field){
        this.nameLabel1.setText(field);
        text1 = field;
        //DATABASE
        //nameLabel2.setText(product.setDescription);
    }
    private Stage loginStage5; // Declare a Stage variable outside the method

    public void switchToScene8(ActionEvent event) throws IOException {
        if (loginStage5 == null) {
            Parent root = FXMLLoader.load(getClass().getResource("visa_or_cash.fxml"));
            loginStage5 = new Stage();
            loginStage5.setTitle("Log in");
            loginStage5.setScene(new Scene(root));
            loginStage5.setOnCloseRequest(e -> loginStage5 = null); // Set the loginStage variable to null when closed
            loginStage5.show();
        }
    }
    @FXML
    private Button checkout;
    @FXML
    private void handleMouseEntered(MouseEvent event) {
        Button[] buttons = {this.checkout};
        for (Button button : buttons) {
            if (event.getSource() == button) {
                button.setStyle("-fx-background-color: green;");
            }
        }
    }
    @FXML
    private void handleMouseExited(MouseEvent event) {
        Button[] buttons = {this.checkout};
        for (Button button : buttons) {
            if (event.getSource() == button) {
                button.setStyle("-fx-background-color: green;");
            }
        }
    }



}
