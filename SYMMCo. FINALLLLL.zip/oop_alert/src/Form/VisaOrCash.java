package Form;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class VisaOrCash {
    private Stage loginStage6; // Declare a Stage variable outside the method

    public void switchToScene9(ActionEvent event) throws IOException {
        if (loginStage6 == null) {
            Parent root = FXMLLoader.load(getClass().getResource("CreditCard.fxml"));
            loginStage6 = new Stage();
            loginStage6.setTitle("Log in");
            loginStage6.setScene(new Scene(root));
            loginStage6.setOnCloseRequest(e -> loginStage6 = null); // Set the loginStage variable to null when closed
            loginStage6.show();
        }
    }
    private Stage loginStage7; // Declare a Stage variable outside the method

    public void switchToScene10(ActionEvent event) throws IOException {
        if (loginStage7 == null) {
            Parent root = FXMLLoader.load(getClass().getResource("Cash.fxml"));
            loginStage7 = new Stage();
            loginStage7.setTitle("Log in");
            loginStage7.setScene(new Scene(root));
            loginStage7.setOnCloseRequest(e -> loginStage7 = null); // Set the loginStage variable to null when closed
            loginStage7.show();
        }
    }
}
