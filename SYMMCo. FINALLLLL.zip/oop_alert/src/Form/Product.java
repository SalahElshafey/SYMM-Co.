package Form;

public class Product {
    private String type;
    private String item_name;
    //private Sign_up = new Sign_up;
}
