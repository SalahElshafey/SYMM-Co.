package Form;

import java.util.Date;

final class Payment {
    //private Order order = new Order();
    private PaymentMethod paymentMethod = new PaymentMethod();
    //private PurchasedItems purchasedItems = new PurchasedItems();
    private String status;
    private double amount;
    private Date datePaid;
    public void processPayment(){

    }
}
