package Form;

//Done
public interface Client_System {
    void client(String name,String id);
    void client(String name,String id,String email, String password,String address,String phone,String bio);
}
