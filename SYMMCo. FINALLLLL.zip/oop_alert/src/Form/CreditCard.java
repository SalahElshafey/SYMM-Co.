package Form;

import Classes.PaymentMethod;
import javafx.animation.KeyFrame;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import javafx.scene.control.TextField;

import java.io.IOException;

public class CreditCard {
    @FXML
    private ImageView img1;
    @FXML
    private ImageView img2;

    @FXML
    private Label label1;//Card
    @FXML
    private Label label2;//month
    @FXML
    private Label label3;//year
    @FXML
    private Label label4;//Card name
    @FXML
    private Label label5;//CVV
    @FXML
    private TextField Text1;//card#
    @FXML
    private TextField Text2;//month
    @FXML
    private TextField Text3;//yaer
    @FXML
    private TextField Text4;//card name
    @FXML
    private TextField Text5;//cvv



    private ScaleTransition flipIn;
    private ScaleTransition flipOut;
    private PaymentMethod paymentMethod = new PaymentMethod();
    public CreditCard() {
    }
    @FXML
    private void handleButtonAction(MouseEvent event) {
        if(areAllFieldsFilled()) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("checkout_done.fxml"));
                Parent root = loader.load();
                paymentMethod.setCard_holder_name(Text4.getText());
                paymentMethod.setCard_number(Text1.getText());
                paymentMethod.setExp_Date(Text2.getText() + "/" + Text3.getText());
                paymentMethod.setCVV(Text5.getText());
                // Create a new stage
                Stage sideViewStage = new Stage();
                sideViewStage.setScene(new Scene(root));

                sideViewStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                FXMLLoader loaders = new FXMLLoader(getClass().getResource("Required.fxml"));
                Parent root = loaders.load();
                Stage warningStage = new Stage();
                warningStage.initStyle(StageStyle.UNDECORATED);
                warningStage.setX(-5);
                warningStage.setY(900);
                warningStage.setScene(new Scene(root));

                Label warningLabel = (Label) loaders.getNamespace().get("warningLabel");
                warningLabel.setText("Please fill all text fields!");

                // Show the warning stage for a short duration
                Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> {
                    warningStage.close();
                    // Open the original form again
                }));
                timeline.setCycleCount(1);
                timeline.play();
                // Show the warning stage
                warningStage.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private boolean areAllFieldsFilled() {
        if (Text4.getText() == null || Text4.getText().isEmpty()
                || Text1.getText() == null || Text1.getText().isEmpty()
                || Text2.getText() == null || Text2.getText().isEmpty()
                || Text3.getText() == null || Text3.getText().isEmpty()
                || Text5.getText() == null || Text5.getText().isEmpty()) {
            return false;
        }
        return true;
    }


    public boolean i=true;//Flag for not flipping the card on the start of the app until cvv clicked

    @FXML
    //Flipping to the front card
    public void handleText1(MouseEvent mouseEvent) {
        if(i==false ){
            flipOut = new ScaleTransition(Duration.seconds(1), img1);//Number of seconds for the flip
            flipOut.setFromX(0);//represents a completely flattened image (no width)
            flipOut.setToX(1);//1 represents the original width of the image.
            flipOut.play();
        }
        i=true;
        img1.setVisible(true);
        img1.setImage(new Image("Form/Front-removebg-preview.png"));
        img2.setVisible(false);

    }

    @FXML
    //flipping of the back
    public void handleText2(MouseEvent mouseEvent) {
        if(mouseEvent.getClickCount()==1){
            flipIn = new ScaleTransition(Duration.seconds(1), img2);//Number of seconds for the flip
            flipIn.setFromX(0);
            flipIn.setToX(1);
            flipIn.play();}
        img2.setVisible(true);
        img2.setImage(new Image("Form/logos/Back-removebg-preview.png"));
        img1.setVisible(false);
        i=false;
    }
    @FXML
    public void front() {
        label1.setVisible(true);
        label2.setVisible(true);
        label3.setVisible(true);
        label4.setVisible(true);
        label5.setVisible(false);
        if(Text1.getLength()<=16){
            label1.setText(Text1.getText());}
        if(Text2.getLength()<=2){
            label2.setText(Text2.getText());}
        if(Text3.getLength()<=2){
            label3.setText(Text3.getText());}
        label4.setText(Text4.getText());
    }
    @FXML
    public void back(){
        label1.setVisible(false);
        label2.setVisible(false);
        label3.setVisible(false);
        label4.setVisible(false);
        label5.setVisible(true);
        if(Text5.getLength()<=3){
            label5.setText(Text5.getText());
        }
    }
}


