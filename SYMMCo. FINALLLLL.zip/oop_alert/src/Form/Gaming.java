package Form;

import Classes.Product;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class Gaming {
    @FXML
    private Button BTN1, BTN2, BTN3, BTN4, BTN5, BTN6, BTN7, BTN8, BTN9, BTN10, BTN11, BTN12,BTN13,BTN14,BTN15,BTN16,CARTBTN;
    @FXML
    private void startShake_button(MouseEvent mouseEvent) {
        Button button = (Button) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(button.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(button.translateXProperty(), 0))
        );
        timeline.play();
    }
    @FXML
    private void handleMouseEntered(MouseEvent event) {
        Button[] buttons = {BTN1, BTN2, BTN3, BTN4, BTN5, BTN6, BTN7, BTN8, BTN9, BTN10, BTN11, BTN12,BTN13,BTN14,BTN15,BTN16,CARTBTN};
        for (Button button : buttons) {
            if (event.getSource() == button) {
                button.setStyle("-fx-background-color: green;");
            }
        }
    }

    @FXML
    private void handleMouseExited(MouseEvent event) {
        Button[] buttons = {BTN1, BTN2, BTN3, BTN4, BTN5, BTN6, BTN7, BTN8, BTN9, BTN10, BTN11, BTN12,BTN13,BTN14,BTN15,BTN16,CARTBTN};
        for (Button button : buttons) {
            if (event.getSource() == button) {
                button.setStyle("-fx-background-color: black;");
            }
        }
    }
    @FXML
    TextField textfield1;

    private Stage stage;
    private Scene scene;
    private Parent root;
    private Product product = new Product();
    public void AddToCart (ActionEvent event) throws IOException {
        product.setType(textfield1.getText());
        //DATABASE
        //label.setText(product.setDescription); in CART NOT HERE

        String CPUorGPU = this.textfield1.getText();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("Cart.fxml"));
        this.root = loader.load();
        Cart cart= loader.getController();
        cart.displayName(CPUorGPU);
        this.stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(scene);
        this.stage.show();
    }

}
