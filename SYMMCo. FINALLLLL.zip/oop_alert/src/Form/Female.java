package Form;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class Female {
    /*
    @FXML
    private Button avatarOption1; // Example avatar selection option
    // Add other avatar selection options as needed

    @FXML
    private void handleAvatarSelection() {
        // Get the selected avatar
        Image selectedAvatar = new Image("path/to/selected/avatar.jpg");

        // Create an instance of the AvatarStorageForm
        Sign_up avatarStorageForm = new Sign_up();

        // Pass the selected avatar to the AvatarStorageForm
        avatarStorageForm.receiveSelectedAvatar(selectedAvatar);
    }
    */
}

