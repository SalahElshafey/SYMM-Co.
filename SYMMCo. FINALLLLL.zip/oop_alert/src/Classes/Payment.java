package Classes;

import java.util.Date;

final class Payment {
    //private Order order = new Order();
    private PaymentMethod paymentMethod = new PaymentMethod();
    private String status;
    private double amount;
    private Date datePaid;
    public void processPayment(){

    }
}
