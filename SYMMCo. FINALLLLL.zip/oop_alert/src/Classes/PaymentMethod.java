package Classes;

//DONE
public final class PaymentMethod {
    private String card_holder_name;
    private String card_number;
    private String Exp_Date;
    private String CVV;
    private static PaymentMethod instance; // Singleton instance

    public PaymentMethod() {
        // Private constructor to prevent instantiation from outside the class
    }

    public static PaymentMethod getInstance() {
        if (instance == null) {
            instance = new PaymentMethod();
        }
        return instance;
    }

    private void Cash(){
        return;
    }

    public String getCard_holder_name() {
        return card_holder_name;
    }

    public void setCard_holder_name(String card_holder_name) {
        this.card_holder_name = card_holder_name;
    }

    public String getCard_number() {
        return card_number;
    }

    public void setCard_number(String card_number) {
        this.card_number = card_number;
    }

    public String getExp_Date() {
        return Exp_Date;
    }

    public void setExp_Date(String exp_Date) {
        Exp_Date = exp_Date;
    }

    public String getCVV() {
        return CVV;
    }

    public void setCVV(String CVV) {
        this.CVV = CVV;
    }
}
