package Form;

import java.util.Date;
//DONE
public class OrderItem {
    private Product product = new Product();
    private int quantity;
    private String description;
    private String modelName;
    private Date dateCreated = new Date();
    public OrderItem(int quantity,String description,String modelName){
        this.quantity = quantity;
        this.description = description;
        this.modelName = modelName;
    }

}
