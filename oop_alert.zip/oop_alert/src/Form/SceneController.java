package Form;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.IOException;

public class SceneController {
    private RotateTransition rotateTransition;
    @FXML
    private ImageView image;
    @FXML
    private Button button;
    @FXML
    private Sign_up signUp = new Sign_up();
    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FORM.fxml"));
        Stage stage = new Stage();
        stage.setTitle("HomePage");
        stage.setScene(new Scene(root));
        stage.show();
    }
    private Stage signUpStage; // Declare a Stage variable outside the method

    public void switchToScene2(ActionEvent event) throws IOException {
        if (signUpStage == null) {
            Parent root = FXMLLoader.load(getClass().getResource("Sign_up.fxml"));
            signUpStage = new Stage();
            signUpStage.setTitle("Sign up");
            signUpStage.setScene(new Scene(root));
            signUpStage.setOnCloseRequest(e -> signUpStage = null); // Set the signUpStage variable to null when closed
            signUpStage.show();
        }
    }

    private Stage loginStage; // Declare a Stage variable outside the method

    public void switchToScene3(ActionEvent event) throws IOException {
        if (loginStage == null) {
            Parent root = FXMLLoader.load(getClass().getResource("Log_in.fxml"));
            loginStage = new Stage();
            loginStage.setTitle("Log in");
            loginStage.setScene(new Scene(root));
            loginStage.setOnCloseRequest(e -> loginStage = null); // Set the loginStage variable to null when closed
            loginStage.show();
        }
    }

    @FXML
    private void startShake_button(MouseEvent mouseEvent) {
        Button button = (Button) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(button.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(button.translateXProperty(), 0))
        );
        timeline.play();
    }
    @FXML
    private void handleMouseEntered1(MouseEvent event) {
        if (rotateTransition == null) {
            rotateTransition = new RotateTransition(Duration.seconds(0.5f), image);
            rotateTransition.setByAngle(360);
            rotateTransition.setAutoReverse(false);
        }
        rotateTransition.play();
    }
    @FXML
    private void handleButtonAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("side_view.fxml"));
            Parent root = loader.load();

            // Create a new stage
            Stage sideViewStage = new Stage();
            sideViewStage.initStyle(StageStyle.UNDECORATED);
            sideViewStage.setX(-10);
            sideViewStage.setY(0);
            sideViewStage.setScene(new Scene(root));
            root.setOnMouseExited(e -> sideViewStage.close());
            // Show the stage
            sideViewStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean isWindowOpen1 = false; // boolean variable to track if the window is open

    @FXML
    private void ImageAction1(MouseEvent event) {
        if (isWindowOpen1) {
            return; // Window is already open, so return without doing anything
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("elect.fxml"));
            Parent root = loader.load();

            // Create a new stage
            Stage form = new Stage();
            form.setScene(new Scene(root));
            // Show the stage
            form.show();

            // Set the boolean variable to indicate that the window is now open
            isWindowOpen1 = true;

            // Add an event handler to detect when the window is closed
            form.setOnCloseRequest(windowEvent -> {
                isWindowOpen1 = false; // Set the boolean variable to indicate that the window is closed
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private boolean isWindowOpen2 = false; // boolean variable to track if the window is open

    @FXML
    private void ImageAction2(MouseEvent event) {
        if (isWindowOpen2) {
            return; // Window is already open, so return without doing anything
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("supermarket.fxml"));
            Parent root = loader.load();

            // Create a new stage
            Stage form = new Stage();
            form.setScene(new Scene(root));
            // Show the stage
            form.show();

            // Set the boolean variable to indicate that the window is now open
            isWindowOpen2 = true;

            // Add an event handler to detect when the window is closed
            form.setOnCloseRequest(windowEvent -> {
                isWindowOpen2 = false; // Set the boolean variable to indicate that the window is closed
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private boolean isWindowOpen3 = false; // boolean variable to track if the window is open

    @FXML
    private void ImageAction3(MouseEvent event) {
        if (isWindowOpen3) {
            return; // Window is already open, so return without doing anything
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("gaming.fxml"));
            Parent root = loader.load();

            // Create a new stage
            Stage form = new Stage();
            form.setScene(new Scene(root));
            // Show the stage
            form.show();

            // Set the boolean variable to indicate that the window is now open
            isWindowOpen3 = true;

            // Add an event handler to detect when the window is closed
            form.setOnCloseRequest(windowEvent -> {
                isWindowOpen3 = false; // Set the boolean variable to indicate that the window is closed
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
