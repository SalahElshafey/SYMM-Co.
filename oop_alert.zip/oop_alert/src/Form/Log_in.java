package Form;

import Classes.Client;
import Classes.Seller;
import com.mongodb.client.*;
import com.mongodb.client.MongoClients;
import com.mongodb.client.model.Filters;
import javafx.animation.*;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;


public class Log_in{

    MongoClient mongo= MongoClients.create("mongodb+srv://SalahElshafey:Salah1234@cluster0.cwbcqvp.mongodb.net/");
    MongoDatabase db=mongo.getDatabase("SYMMCo");
    MongoCollection<Document> Login= db.getCollection("Login");


    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label label;
    @FXML
    private ImageView image;
    @FXML
    private Stage loginStage1;
    @FXML
    private Button closeButton;
    private Client client = new Client();
    private Seller seller = new Seller();
    private Profile profile;
    private RotateTransition rotateTransition;
    public boolean isCredentialsValid() {



        int i=0;
        int j=0;

        FindIterable<Document> doc = Login.find(Filters.and(
                Filters.eq("Email", emailField.getText()),
                Filters.eq("Password", passwordField.getText())
        ));

        for (Document d : doc) {
            System.out.println(d.get("Email") + " " + d.get("Password"));
            return true; // Credentials are valid
        }

        return false;}



    @FXML
    private void closeForm(ActionEvent event) throws IOException {
        if (areAllFieldsFilled()) {
            if(!isCredentialsValid()){
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("invalid_info.fxml"));
                    Parent root = loader.load();
                    Stage invalid = new Stage();
                    invalid.initStyle(StageStyle.UNDECORATED);
                    invalid.setX(-5);
                    invalid.setY(900);
                    invalid.setScene(new Scene(root));

                    // Show the warning stage for a short duration
                    Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> {
                        invalid.close();
                        // Open the original form again
                    }));
                    timeline.setCycleCount(1);
                    timeline.play();
                    // Show the warning stage
                    invalid.showAndWait();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else{
                if (loginStage1 == null) {
                    Parent root = FXMLLoader.load(getClass().getResource("Success_login.fxml"));
                    loginStage1 = new Stage();
                    loginStage1.setTitle("Log in");
                    loginStage1.setScene(new Scene(root));
                    loginStage1.setOnCloseRequest(e -> loginStage1 = null); // Set the loginStage variable to null when closed
                    loginStage1.show();
                }
            }
        }
        else{
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Required.fxml"));
                Parent root = loader.load();
                Stage warningStage = new Stage();
                warningStage.initStyle(StageStyle.UNDECORATED);
                warningStage.setX(-5);
                warningStage.setY(900);
                warningStage.setScene(new Scene(root));

                Label warningLabel = (Label) loader.getNamespace().get("warningLabel");
                warningLabel.setText("Please fill all text fields!");

                // Show the warning stage for a short duration
                Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> {
                    warningStage.close();
                    // Open the original form again
                }));
                timeline.setCycleCount(1);
                timeline.play();
                // Show the warning stage
                warningStage.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private boolean areAllFieldsFilled() {
        if (emailField.getText() == null || emailField.getText().isEmpty()
                || passwordField.getText() == null || passwordField.getText().isEmpty()) {
            return false;
        }
        return true;
    }
    @FXML
    private void handleMouseEntered1(MouseEvent event) {
        if (rotateTransition == null) {
            rotateTransition = new RotateTransition(Duration.seconds(0.5f), image);
            rotateTransition.setByAngle(360);
            rotateTransition.setAutoReverse(false);
        }
        rotateTransition.play();
    }
    @FXML
    private void startShake_button(MouseEvent mouseEvent) {
        Button button = (Button) mouseEvent.getSource(); // Get the button that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(button.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(button.translateXProperty(), 0))
        );
        timeline.play();
    }
    @FXML
    private void startShake_text(MouseEvent mouseEvent) {
        TextField textField = (TextField) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(textField.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(textField.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(textField.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(textField.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(textField.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(textField.translateXProperty(), 0))
        );
        timeline.play();
    }
    @FXML
    private void handleMouseEntered(MouseEvent event) {
        // Create a translate transition to move the label's characters vertically
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), label);
        translateTransition.setFromY(0);
        translateTransition.setToY(-20);
        translateTransition.setCycleCount(2);
        translateTransition.setAutoReverse(true);

        // Create a pause transition to pause the animation for a short duration
        PauseTransition pauseTransition = new PauseTransition(Duration.millis(200));

        // Combine the translate and pause transitions into a sequential transition
        Animation animation = new SequentialTransition(translateTransition, pauseTransition);

        // Play the animation
        animation.play();
    }

}
