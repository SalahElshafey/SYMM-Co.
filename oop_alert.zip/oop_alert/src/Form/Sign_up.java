package Form;
import java.util.*;

import Classes.Client;
import Classes.Seller;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.sun.applet2.preloader.event.ConfigEvent;
import com.sun.jndi.toolkit.url.Uri;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javafx.scene.Group;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;

import javafx.scene.image.WritableImage;
import org.bson.Document;


public class Sign_up implements Initializable{

    MongoClient mongo= MongoClients.create("mongodb+srv://SalahElshafey:Salah1234@cluster0.cwbcqvp.mongodb.net/");
    MongoDatabase db=mongo.getDatabase("SYMMCo");
    MongoCollection<Document> Login= db.getCollection("Login");

    private Client client = new Client();
    private Seller seller = new Seller();

    @FXML
    private Button button;
    @FXML
    private Button closeButton;
    @FXML
    private ImageView image;

    private RotateTransition rotateTransition;

    @FXML
    private Label label;

    // DATA--------------------------------------------------------------
    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextArea bioField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField phoneNumberTextField;
    @FXML
    private DatePicker datePicker;
    @FXML
    private ChoiceBox<String> myChoiceBox;
    @FXML
    private ImageView imageView1_female;
    @FXML
    private ImageView imageView2_female;
    @FXML
    private ImageView imageView3_female;
    @FXML
    private ImageView imageView4_female;
    @FXML
    private ImageView imageView5_female;
    @FXML
    private ImageView imageView6_female;
    @FXML
    private ImageView imageView7_female;
    @FXML
    private ImageView imageView8_female;
    @FXML
    private ImageView imageView9_female;
    @FXML
    private ImageView imageView10_female;
    @FXML
    private ImageView imageView11_female;
    @FXML
    private ImageView imageView1_male;
    @FXML
    private ImageView imageView2_male;
    @FXML
    private ImageView imageView3_male;
    @FXML
    private ImageView imageView4_male;
    @FXML
    private ImageView imageView5_male;
    @FXML
    private ImageView imageView7_male;
    @FXML
    private ImageView imageView9_male;
    @FXML
    private ImageView imageView22;
    private List<Image> imageList;
    //void showSignUpForm() {
           // imageList = new ArrayList<>();
           // imageList.add(new Image("Form/male/1.png"));
            //imageList.add(new Image("Form/male/2.png"));
            //Image randomImage = getRandomImage();
            //imageView22.setImage(randomImage);
    //}
    private Image getRandomImage() {
        // Generate a random index within the range of the image list
        int randomIndex = new Random().nextInt(imageList.size());

        // Retrieve the image at the randomly generated index
        return imageList.get(randomIndex);
    }
    //@FXML
    //private String[] user = {"Client", "Seller"};
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> userOptions = FXCollections.observableArrayList("Client", "Seller");
        myChoiceBox.setItems(userOptions);
    }
    // DATA--------------------------------------------------------------
    @FXML
    private void handleMouseEntered1(MouseEvent event) {
        if (rotateTransition == null) {
            rotateTransition = new RotateTransition(Duration.seconds(0.5f), image);
            rotateTransition.setByAngle(360);
            rotateTransition.setAutoReverse(false);
        }
        rotateTransition.play();
    }
    private Stage maleStage;
    @FXML
    private void handleButtonClick1(ActionEvent event) throws IOException {
        if (maleStage == null) {
            Parent root = FXMLLoader.load(getClass().getResource("male.fxml"));
            maleStage = new Stage();
            maleStage.setTitle("choose avatar");
            maleStage.setScene(new Scene(root));
            maleStage.setOnCloseRequest(e -> maleStage = null); // Set the signUpStage variable to null when closed
            maleStage.show();
        }
    }

    private Stage femaleStage; // Declare a Stage variable outside the method

    @FXML
    private void handleButtonClick2(ActionEvent event) throws IOException {
        if (femaleStage == null) {
            Parent root = FXMLLoader.load(getClass().getResource("female.fxml"));
            femaleStage = new Stage();
            femaleStage.setTitle("choose avatar");
            femaleStage.setScene(new Scene(root));
            femaleStage.setOnCloseRequest(e -> femaleStage = null); // Set the signUpStage variable to null when closed
            femaleStage.show();
        }
    }

    private Stage signUpStage; // Declare a Stage variable outside the method

    @FXML
    private void handleButtonClick(MouseEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("choose_gender.fxml"));
            signUpStage = new Stage();
            signUpStage.setTitle("choose avatar type");
            signUpStage.setScene(new Scene(root));
            signUpStage.setOnCloseRequest(e -> signUpStage = null); // Set the signUpStage variable to null when closed
            signUpStage.show();
    }

    @FXML
    private void validatePhoneNum() {
        phoneNumberTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\+?\\d{0,12}")) {
                phoneNumberTextField.setText(oldValue);
            }
        });
    }

    @FXML
    private void Birth() {
        LocalDate selectedDate = datePicker.getValue();
    }

    @FXML
    private Label ids;

    @FXML
    private void closeForm(ActionEvent event) {
        if (areAllFieldsFilled()) {
            String randomID = generateRandomID();
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("idForm.fxml"));
                Parent root = loader.load();
                ids = (Label) loader.getNamespace().get("ids"); // Retrieve the ids element from the loaded FXML file
                ids.setText(randomID);
                // Save Client Values
                if ("Client".equals(myChoiceBox.getValue())) {
                    client.setId(ids.getText());
                    client.setName(nameField.getText());
                    client.setEmail(emailField.getText());
                    client.setPassword(passwordField.getText());
                    client.setAddress(addressField.getText());
                    client.setPhone(phoneNumberTextField.getText());
                    client.setBirth(datePicker.getValue());
                    client.setBio(bioField.getText());
                    client.saveC();
                    Document client=new Document("ID",ids.getText()).append("Type","Client").append("Name",nameField.getText()).append("Email",emailField.getText()).append("Password",passwordField.getText()).append("Address",addressField.getText()).append("Phone number",phoneNumberTextField.getText()).append("BirthDate",datePicker.getValue()).append("Bio",bioField.getText());
                    Login.insertOne(client);
                }
                // Save Seller Values
                else if ("Seller".equals(myChoiceBox.getValue())) {
                    seller.setId(ids.getText());
                    seller.setName(nameField.getText());
                    seller.setEmail(emailField.getText());
                    seller.setPassword(passwordField.getText());
                    seller.setAddress(addressField.getText());
                    seller.setPhone(phoneNumberTextField.getText());
                    seller.setBirth(datePicker.getValue());
                    seller.setBio(bioField.getText());
                    seller.saveS();
                    Document Seller=new Document("ID",ids.getText()).append("Type","Seller").append("Name",nameField.getText()).append("Email",emailField.getText()).append("Password",passwordField.getText()).append("Address",addressField.getText()).append("Phone number",phoneNumberTextField.getText()).append("BirthDate",datePicker.getValue()).append("Bio",bioField.getText());
                    Login.insertOne(Seller);
                }
                // ====================
                Stage ID_FORM = new Stage();
                ID_FORM.setScene(new Scene(root));
                ID_FORM.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                FXMLLoader loaders = new FXMLLoader(getClass().getResource("Required.fxml"));
                Parent root = loaders.load();
                Stage warningStage = new Stage();
                warningStage.initStyle(StageStyle.UNDECORATED);
                warningStage.setX(-5);
                warningStage.setY(900);
                warningStage.setScene(new Scene(root));

                Label warningLabel = (Label) loaders.getNamespace().get("warningLabel");
                warningLabel.setText("Please fill all text fields!");

                // Show the warning stage for a short duration
                Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> {
                    warningStage.close();
                    // Open the original form again
                }));
                timeline.setCycleCount(1);
                timeline.play();
                // Show the warning stage
                warningStage.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private boolean areAllFieldsFilled() {
        if (nameField.getText() == null || nameField.getText().isEmpty()
                || emailField.getText() == null || emailField.getText().isEmpty()
                || passwordField.getText() == null || passwordField.getText().isEmpty()
                || addressField.getText() == null || addressField.getText().isEmpty()
                || datePicker.getEditor().getText() == null || datePicker.getEditor().getText().isEmpty()
                || (myChoiceBox.getValue() == null || myChoiceBox.getValue().isEmpty())) {
            return false;
        }
        return true;
    }


    private String generateRandomID() {
        Random random = new Random();
        StringBuilder idBuilder = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            int digit = random.nextInt(10); // Generate a random digit from 0 to 9
            idBuilder.append(digit);
        }
        return idBuilder.toString();
    }

    @FXML
    private void startShake_button(MouseEvent mouseEvent) {
        Button button = (Button) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(button.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(button.translateXProperty(), 0))
        );
        timeline.play();
    }

    @FXML
    private void startShake_text(MouseEvent mouseEvent) {
        TextField textField = (TextField) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(textField.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(textField.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(textField.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(textField.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(textField.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(textField.translateXProperty(), 0))
        );
        timeline.play();
    }

    @FXML
    private void handleMouseEntered(MouseEvent event) {
        // Create a translate transition to move the label's characters vertically
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), label);
        translateTransition.setFromY(0);
        translateTransition.setToY(-20);
        translateTransition.setCycleCount(2);
        translateTransition.setAutoReverse(true);

        // Create a pause transition to pause the animation for a short duration
        PauseTransition pauseTransition = new PauseTransition(Duration.millis(200));

        // Combine the translate and pause transitions into a sequential transition
        Animation animation = new SequentialTransition(translateTransition, pauseTransition);

        // Play the animation
        animation.play();
    }
    /*
    @FXML
    private ImageView selectedAvatarImageView;

    @FXML
    private Button storeButton;

    private Image selectedAvatar;

    public void receiveSelectedAvatar(Image avatar) {
        // Store the received avatar
        selectedAvatar = avatar;

        // Display the received avatar in the ImageView
        selectedAvatarImageView.setImage(selectedAvatar);
    }

    @FXML
    private void handleAvatarStorage() {
        // TODO: Implement the logic to store the selected avatar
        // For example, save the selected avatar to a database or file
    }
     */
    private Timer returnTimer;

    @FXML
    private void handleButtonClick22(ActionEvent event) {
        try {
            // Open the URL in the default system browser
            Desktop.getDesktop().browse(new URI("http://localhost:8080/auth/SYMMCo"));

            // Perform any necessary actions while the user is on the external page

            // Schedule the return to the form after a delay of 3 seconds
            scheduleReturnToForm();
        } catch (Exception e) {
            e.printStackTrace();
            showErrorMessage("Error", "Failed to open the URL.");
        }
    }

    private void scheduleReturnToForm() {
        // Cancel the previous timer if running
        if (returnTimer != null) {
            returnTimer.cancel();
        }

        // Create a new timer
        returnTimer = new Timer();

        // Schedule the task to run after 3 seconds
        returnTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Run the code in the JavaFX Application Thread
                Platform.runLater(() -> returnToForm());
            }
        }, 3000); // Delay in milliseconds (3 seconds = 3000 milliseconds)
    }

    private void returnToForm() {
        String randomID = generateRandomID();
        showInformationMessage("SYMM Company", "You have Successfully authenticated\n Your id: " + randomID);
    }
    private void showErrorMessage(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInformationMessage(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
