package Form;

import Classes.Client;
import Classes.Seller;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class Profile{
    @FXML
    private String Name;
    @FXML
    private String Email;
    @FXML
    private String password;
    @FXML
    private String address;
    @FXML
    private String phone_number;
    @FXML
    private LocalDate birth;
    @FXML
    private String Bio;

    //.............
    @FXML
    private TextField Name1;
    @FXML
    private TextField Email1;
    @FXML
    private PasswordField password1;
    @FXML
    private TextField address1;
    @FXML
    private TextField phone_number1;
    @FXML
    private DatePicker birth1;
    @FXML
    private TextArea Bio1;
    public Profile() {
        // Default constructor code
    }
    public Profile(String name, String email, String password, String address, String phone_number, LocalDate birth, String bio) {
        this.Name = name;
        this.Email = email;
        this.password = password;
        this.address = address;
        this.phone_number = phone_number;
        this.birth = birth;
        this.Bio = bio;
        putData();
    }
    private void putData(){
        Name1.setText(Name);
        Email1.setText(Email);
        password1.setText(password);
        address1.setText(address);
        phone_number1.setText(phone_number);
        birth1.setValue(birth);
        Bio1.setText(Bio);
    }
    @FXML
    private Circle circle;
    @FXML
    private void handleButtonClick(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        File selectedFile = fileChooser.showOpenDialog(new Stage());
        if (selectedFile != null) {
            try {
                BufferedImage bufferedImage = ImageIO.read(selectedFile);
                Image image = SwingFXUtils.toFXImage(bufferedImage, null);
                circle.setFill(new ImagePattern(image));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    @FXML
    private void startShake_button(MouseEvent mouseEvent) {
        Button button = (Button) mouseEvent.getSource(); // Get the text field that triggered the event

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(0), new KeyValue(button.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(100), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(200), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(300), new KeyValue(button.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(400), new KeyValue(button.translateXProperty(), 5)),
                new KeyFrame(Duration.millis(500), new KeyValue(button.translateXProperty(), 0))
        );
        timeline.play();
    }
}
