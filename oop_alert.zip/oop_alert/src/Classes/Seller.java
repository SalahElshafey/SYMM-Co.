package Classes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class Seller {
    private String id;
    private String name;
    private String email;
    private String password;
    private String address;
    private String phone;
    private LocalDate Birth;
    private String bio;
    private Date dateCreated;
    public static ArrayList<Seller> sellerList = new ArrayList<>();
    public Seller(){

    }
    public Seller(String id,String name,String email,String password,String address,String phone,LocalDate Birth,String bio) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.address = address;
        this.phone = phone;
        this.Birth = Birth;
        this.bio = bio;
        dateCreated = new Date();
    }
    public void saveS(){
        sellerList.add(new Seller(id,name,email,password,address,phone,Birth,bio));
    }
    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getBirth() {
        return this.Birth;
    }

    public void setBirth(LocalDate birth) {
        this.Birth = birth;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    public String getAddress() {
        return this.address;
    }

    public String getPhone() {
        return this.phone;
    }

    public String getBio() {
        return this.bio;
    }

    public ArrayList<Seller> getSellerList() {
        return sellerList;
    }
}
