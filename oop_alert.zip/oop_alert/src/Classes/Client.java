package Classes;



import Form.Client_System;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class Client implements Client_System {
    private String id;
    private String name;
    private String email;
    private String password;
    private String address;
    private String phone;
    private LocalDate Birth;
    private String bio;
    private Date dateCreated;
    public static ArrayList<Client> clientList = new ArrayList<>();
    public Client(){

    }

    public ArrayList<Client> getClientList() {
        return clientList;
    }

    public LocalDate getBirth() {
        return this.Birth;
    }

    public void setBirth(LocalDate birth) {
        this.Birth = birth;
    }

    public Client(String id, String name, String email, String password, String address, String phone,LocalDate Birth, String bio) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.address = address;
        this.phone = phone;
        this.Birth = Birth;
        this.bio = bio;
        dateCreated = new Date();
    }
    public void saveC(){
        clientList.add(new Client(id,name,email,password,address,phone,Birth,bio));
    }
    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    public String getAddress() {
        return this.address;
    }

    public String getPhone() {
        return this.phone;
    }

    public String getBio() {
        return this.bio;
    }

    public void client(String name,String id,String email, String password,String address,String phone,String bio){
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.address = address;
        this.phone = phone;
        this.bio = bio;
    }
    public void client(String name,String id){
        this.name=name;
        this.id=id;
    }
}
